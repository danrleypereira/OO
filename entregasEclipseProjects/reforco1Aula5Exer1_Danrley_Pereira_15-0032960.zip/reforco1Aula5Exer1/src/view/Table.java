package view;

import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Student;



public class Table extends JFrame{
	String[] columns = {"Nome", "Matrícula", "Média"};
	
	public Table(Vector<Student> students){
		super("Tabela");
		DefaultTableModel tableModel = new DefaultTableModel(columns, 0);
		tableModel.addRow(columns);
		
		for( Student student : students ){
			
			Object[] data = { student.getName(), student.getRegister(), student.getAverageGrades()};

			tableModel.addRow(data);
		}
		
		JTable table = new JTable(tableModel);
		add(table);
		
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		
	}
}
