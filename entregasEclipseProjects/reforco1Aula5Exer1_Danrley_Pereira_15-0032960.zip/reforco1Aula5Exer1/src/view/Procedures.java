package view;

import java.util.Vector;

import javax.swing.JOptionPane;

import model.Student;

public class Procedures {
	public static float enterGrade(int numberGrade) {
		String grade;
		do{
			grade = JOptionPane.showInputDialog(null, "Qual é a nota do aluno na avaliação "+ (numberGrade+1) +"?", "NOTA", JOptionPane.QUESTION_MESSAGE);
		}while(!controller.Validate.isGrade(grade));
		return Float.parseFloat(grade);
	}
	
	public static int doYouWantInsertStudent(){
		return JOptionPane.showConfirmDialog(null, "Deseja adicionar um aluno?", "Confirmar cadastro", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
	}
	public static String inputName(){
		boolean validateIs;
		String name;
		do{
			validateIs = controller.Validate.isName(name = JOptionPane.showInputDialog(null, "Qual é o nome do aluno?", "Nome Aluno", JOptionPane.PLAIN_MESSAGE));
		}while(!validateIs);
		return name;
	}
	public static int inputRegister(){
		String register;
		do{
			register = JOptionPane.showInputDialog(null, "Qual é a matrícula?", "Matrícula Aluno", JOptionPane.PLAIN_MESSAGE);
		}while(!controller.Validate.isRegister(register));
		return Integer.parseInt(register);
	}
	public static void showStudents(Vector<Student> students, int size){
		for (int i = 0; i < 20; i++) {
			System.out.printf("\n");
		}
		System.out.printf("\tNome\t|\tMatrícula\t|\tNota\t|\n");
		for (Student student: students) {
			System.out.printf("\t%s\t|\t\t%d\t|\t%2.1f\t|\n", student.getName(), student.getRegister(), student.getAverageGrades());
		}
		System.exit(0);
	}
}
