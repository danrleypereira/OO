package main;

/*Síntese:
 * 	Objetivo: Cadastrar alunos(máximo de 100 alunos);
 * 	Entrada: Dados do aluno;
 * 	Saída: Apresentar de maneira tabelar todos os cadastro após pular 20 linhas.
 */

import java.util.Vector;

import javax.swing.JOptionPane;

import model.Student;

public class Main {
	public static void main(String[] args) {
		Vector<Student> students = new Vector<Student>(100, 1);
		final int MAXIMO = 100;
		students.add(new Student(view.Procedures.inputName(), view.Procedures.inputRegister()));
		for (int i = 0; i < MAXIMO; i++) {
			int option = view.Procedures.doYouWantInsertStudent();
			switch (option) {
			case JOptionPane.OK_OPTION:
				students.add(new Student(view.Procedures.inputName(), view.Procedures.inputRegister()));
				break;
			case JOptionPane.NO_OPTION:
				view.Procedures.showStudents(students, i);
				break;
			}
		}
		view.Procedures.showStudents(students, students.size());
	}

}
