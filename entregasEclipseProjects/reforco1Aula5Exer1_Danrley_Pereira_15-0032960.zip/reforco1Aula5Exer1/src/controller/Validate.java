package controller;

public class Validate {
	public static boolean isGrade(String grade){
		try{
			float gradeF = Float.parseFloat(grade);
			if(gradeF <= 10 && gradeF >= 0){
				return true;
			}else{
				view.Error.error("As notas só podem estar entre 0 e 10!");
				return false;
			}
		}catch(NumberFormatException e){
			view.Error.error();
			return false;
		}
	}
	public static boolean isName(String name){
		try{
			Float.parseFloat(name);
			Integer.parseInt(name);
			view.Error.error();
			return false;
		}catch(NumberFormatException e){
			return true;
		}
	}
	public static boolean isRegister(String register){
		try {
			int registerInt = Integer.parseInt(register);
			if(registerInt > 0){
				return true;
			}else{
				view.Error.error("A matrícula não pode ser um número negativo!");
				return false;
			}
		} catch (NumberFormatException e) {
			view.Error.error();
			return false;
		}
	}
}
