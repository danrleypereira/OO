package model;

public class Student {
	private String name;
	private int register;
	private float[] grades = new float[3];
	private float averageGrades;
	
	public Student(String name, int register) {
		this.name = name;
		this.register = register;
		this.averageGrades = 0;
		for(int i=0; i<3; i++){
			this.grades[i] = view.Procedures.enterGrade(i);
			this.averageGrades += this.grades[i];
		}
		this.averageGrades = this.averageGrades/3;
	}

	public String getName() {
		return name;
	}

	public int getRegister() {
		return register;
	}

	public float getAverageGrades() {
		return averageGrades;
	}
	
}
