package model;

abstract class Person {
	private String name;
	
	Person(String name) {
		this.name = name;
	}

	String getName() {
		return name;
	}
}
