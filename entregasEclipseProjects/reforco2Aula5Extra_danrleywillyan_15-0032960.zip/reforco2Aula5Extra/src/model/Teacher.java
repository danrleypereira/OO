package model;

public final class Teacher extends Person{
	private int numberClasses;

	public Teacher(String name) {
		super(name);
		this.numberClasses = 1;
	}
	
	int getNumberClasses() {
		return numberClasses;
	}

	void addClass(){
		this.numberClasses++;
	}
}
