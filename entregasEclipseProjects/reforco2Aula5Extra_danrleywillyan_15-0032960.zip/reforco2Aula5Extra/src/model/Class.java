package model;

import java.util.Vector;

public class Class {
	private Vector<Student> students;
	private Teacher teacher;
	
	public Class(Vector<Student> students, Teacher teacher) {
		this.students = students;
		this.teacher = teacher;
	}
	
	public int getSizeStudents() {
		return students.size();
	}
	public void addStudent(Student student){
		if(getSizeStudents() < 120){
			this.students.add(student);
		}
	}
	public float getAverageStudentAt(int index) {
		return this.students.get(index).getAverage();
	}
	public Teacher getTeacher() {
		return teacher;
	}
}
