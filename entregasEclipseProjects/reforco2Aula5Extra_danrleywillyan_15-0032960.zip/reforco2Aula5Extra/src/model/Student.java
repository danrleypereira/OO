package model;

final class Student extends Person {
	private float average;

	Student(String name, float average) {
		super(name);
		this.average = average;
	}

	float getAverage() {
		return average;
	}	
}
