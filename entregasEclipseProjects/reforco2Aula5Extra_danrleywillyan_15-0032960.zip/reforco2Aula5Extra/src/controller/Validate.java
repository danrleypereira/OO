package controller;

import view.Error;

public class Validate {
	private static boolean isNumber(String number){
		try {
			Float.parseFloat(number);
			return true;
		} catch (NumberFormatException e) {
			Error.showError();
			return false;
		}
	}
	public static boolean isName(String name){
		try {
			Float.parseFloat(name);
			Error.showErrorWithMessage("Não pode ser um número.");
			return false;
		} catch (NumberFormatException e) {
			return true;
		}
	}
	public static boolean isNumberStudents(String numberStudents){
		try {
			if(!isNumber(numberStudents)){
				return false;
			}else if(Integer.parseInt(numberStudents) <= 120 && Integer.parseInt(numberStudents) >= 2){
				return true;
			}else{
				Error.showErrorWithMessage("Tem que ser um número inteiro entre 2 e 120.");
				return false;
			}
		} catch (NumberFormatException e) {
			Error.showErrorWithMessage("Tem que ser um número inteiro.");
			return false;
		}
	}
	public static boolean isAverage(String average){
		if(!isNumber(average)){
			return false;
		}else if(Float.parseFloat(average) >= 0 && Float.parseFloat(average) <= 10){
			return true;
		}else{
			Error.showErrorWithMessage("Tem que ser um número entre 0 e 10.");
			return false;
		}
	}
}
