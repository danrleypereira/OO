package controller;
import java.util.Vector;

import model.*;
import model.Class;

public class Datas {	
	public static void main(String[] args){
		Vector<Class> classes;
	}
	public static Class getClassAt(int index){
		return classes.get(index);
	}
	public static Vector<T> getClasses(){
		return classes;
	}
	public Vector<T> getTeachersClasses(Teacher teacher){
		Vector<T> teacherClasses = new Vector<T>();
		for(int i = 0; i < getSize(); i++ ){
			if(classes.get(i).getTeacher().equals(teacher)){
				teacherClasses.add(classes.get(i));
			}
		}
		return teacherClasses;
	}
	private int getSize(){
		return classes.size();
	}
}
