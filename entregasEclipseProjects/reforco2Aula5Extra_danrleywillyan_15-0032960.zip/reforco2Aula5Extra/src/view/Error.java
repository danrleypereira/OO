package view;

import javax.swing.JOptionPane;

public class Error {
	public static void showError(){
		JOptionPane.showConfirmDialog(null, "Dado inválido", "Erro", 
				JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
	}
	public static void showErrorWithMessage(String message){
		JOptionPane.showConfirmDialog(null, message, "Erro", 
				JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
	}
}
