package view;

import javax.swing.JOptionPane;

public class Procedures {
	public static void insertTeacher(){
		
	}
	private static String inputDialog(String userMessage, String windowName){
		return JOptionPane.showInputDialog(null, userMessage, windowName,JOptionPane.PLAIN_MESSAGE);
	}
}
