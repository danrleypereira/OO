import java.util.Scanner;

	/** Síntese 
	*    Objetivo: Calcular fatorial de N números;
	*    Entrada:  Número N e N números;
	*    Saída:    Fatorial dos N números inseridos.
	*/

public class FatorialNumbers {

	public static void main(String[] args) {
		//declarações
		int quantosNumeros;
		Scanner ler = new Scanner(System.in);
		
		//instruções
		System.out.println("Quantos números você deseja inserir?(insira um número maior que zero)\t");
		do{
			quantosNumeros = ler.nextInt();
		}while(quantosNumeros < 0);
		
		int[] numeros = new int[quantosNumeros];
		int[] fatoriais = new int[quantosNumeros];
		
		for(int i = 0; i< quantosNumeros; i++){
			System.out.println("Numero: "+ (i+1));
			numeros[i] = ler.nextInt();
			fatoriais[i] = calcularFatorial(numeros[i]);
		}
		
		limpaTela();
		for(int i=0; i<quantosNumeros; i++){
			System.out.println("Numero:\t"+ numeros[i] + " tem fatorial:\t" + fatoriais[i]);
		}
		
		ler.close();
		
	}
	
	private static int calcularFatorial(int numero) {
		if(numero > 0){
			return numero*calcularFatorial(numero-1);
		}else{
			return 1;
		}
	}

	private static void limpaTela(){
		for(int i = 0; i<50; i++){
			System.out.println("\n");
		}
	}
	

}
