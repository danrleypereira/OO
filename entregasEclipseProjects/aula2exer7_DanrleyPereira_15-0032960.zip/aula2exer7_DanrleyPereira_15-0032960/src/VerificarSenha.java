import java.util.ArrayList;

public class VerificarSenha {

	/**Síntese 
	 * 	Objetivo: Cadastrar senha e permitir que outro usuário tente acertar esta; 
	 * 	Entrada: Senha do usuário e senhas geradas por outro usuário;
	 *  Saída: Se o usuário não proprietário da senha errar 9 vezes printar messagem de autodestruição;
	 *  	Se acertar parabenizeo.
	 */

	public static void main(String[] args) {
		//declarações
		
		//intruções
		definirSenha();
	}

}
