import java.util.ArrayList;


public class Usuario {
	//declarações
	
	private ArrayList<char> senha = new ArrayList<char>();
	
	
	//instruções
	public void definirSenha(){
		
	}
	
	public void verificarSenha(){
		
	}
	
	
}
