

public class Student {
	String name = new String();
	String registration= new String();
	float average;
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setRegistration(String registration) {
		this.registration = registration;
	}
	
	public void setAverage(float average) {
		this.average = average;
	}
	
	public String getName() {
		return name;
	}
	
	public String getRegistration() {
		return registration;
	}
	
	public float getAverage() {
		return average;
	}
}
