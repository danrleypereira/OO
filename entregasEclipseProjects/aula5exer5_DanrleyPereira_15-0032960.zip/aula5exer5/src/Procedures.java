import javax.swing.JOptionPane;


public class Procedures {

	public static boolean doesUserWantContinue(){
		
		int optionPanel = JOptionPane.showConfirmDialog(null,"Você quer adiconar um aluno?","Principal", JOptionPane.YES_NO_OPTION);

		switch (optionPanel) {
		case JOptionPane.YES_OPTION:
		  return true;
		case JOptionPane.NO_OPTION:
		  return false;
		default:
			return false;
		}
	}
	
	public static Student createStudent(){
		Student student = new Student();
		
		return student;
	}


	public static void showTable() {
		
	}
}
