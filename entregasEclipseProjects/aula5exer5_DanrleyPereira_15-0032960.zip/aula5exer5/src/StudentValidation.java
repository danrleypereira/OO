/**
 * Excessão: 
 * 	Entrada1: 
 * 			Nome: Danrley Sapo Largado;
 * 			Matrícula: 0223;
 * 			média final: 8;
 * 	Entrada2:
 * 			Nome: Gois da Silva Largado;
 * 			Matrícula: 230;
 * 			média final: 20;
 * 	Entrada3: 
 * 			Nome: Gabriela Friends Forever;
 * 			Matrícula: mil;
 * 			média final: 2;
			
 * **/


public class StudentValidation {

	public static boolean validationName(String text) {
		if(text.isEmpty()){
			return true;
		}else{
			return false;
		}
	}

	public static boolean validationRegistration(String text) {
		int registration = Integer.parseInt(text)
		
	}

	public static boolean validationAverage(float parseFloat) {
		
		
	}
		
		
	
}
