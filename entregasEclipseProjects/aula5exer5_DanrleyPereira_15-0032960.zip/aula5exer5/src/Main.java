/**
 * Síntese 
	 * Objetivo: Armazenar dados de quantos alunos o usuário desejar tratando as excessões;
	 * Entrada: Nome completo de um aluno, sua matrícula na instituição e sua média final; 
	 * Saída: Apresentar os dados, depois de os ter armazenado, em formato tabelar.
 */

import java.util.ArrayList;

import javax.swing.JPanel;

public class Main {
	ArrayList<String> StudentArray = new ArrayList<String>();
	public static void main(String[] Args) throws InterruptedException{
		//variables
		ArrayList<Student> StudentArray = new ArrayList<Student>();
		View panel = new View();
		
		//procedures
		while( Procedures.doesUserWantContinue() ){
			Thread.sleep(200000000);
		}
		
		if(StudentArray.size() > 0){
			Procedures.showTable();
		}
		System.exit(0);
	}
}
