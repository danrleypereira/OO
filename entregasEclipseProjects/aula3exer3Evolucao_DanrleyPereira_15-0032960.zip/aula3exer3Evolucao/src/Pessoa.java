
public class Pessoa {
	private float altura;
	private int idade;
	private String nome;

	public float getAltura() {
		return altura;
	}
	
	public int getIdade() {
		return idade;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setAltura(float altura) {
		this.altura = altura;
	}
	
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}

}
